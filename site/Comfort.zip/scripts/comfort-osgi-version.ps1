# Общие функции версии tormozit.comfort в OSGi-профиле PDE (MANIFEST, bundles.info, dev.properties).
$ErrorActionPreference = 'Stop'

$script:ComfortRepoRoot = if ($PSScriptRoot) { Split-Path (Split-Path $PSScriptRoot -Parent) -Parent } else { 'C:\VC\EDT.Comfort' }
$script:ComfortVersionFile = Join-Path $script:ComfortRepoRoot 'site\version.txt'
$script:ComfortManifestPath = Join-Path $script:ComfortRepoRoot 'plugin\META-INF\MANIFEST.MF'
$script:ComfortBackupOsgi = Join-Path $script:ComfortRepoRoot 'launch\backup\osgi'
$script:ComfortWsOsgi = 'C:\VC\EDT-plugin-WS\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application'
$script:ComfortBundlesInfoRel = 'org.eclipse.equinox.simpleconfigurator\bundles.info'
$script:ComfortPluginLocation = 'file:/C:/VC/EDT.Comfort/plugin/'
# Бандл проверок: версия своя и со сборками не меняется (см. plugin.checks/README.md),
# но в OSGi-профиле PDE он должен быть, иначе проверки «Комфорта» в запуске просто отсутствуют.
$script:ComfortChecksManifestPath = Join-Path $script:ComfortRepoRoot 'plugin.checks\META-INF\MANIFEST.MF'
$script:ComfortChecksLocation = 'file:/C:/VC/EDT.Comfort/plugin.checks/'
# Бандл раннего старта: должен стартовать вместе с фреймворком (последнее поле bundles.info = true),
# иначе его WeavingHook не успевает до загрузки классов EDT и SWT (см. plugin.early/README.md).
$script:ComfortEarlyManifestPath = Join-Path $script:ComfortRepoRoot 'plugin.early\META-INF\MANIFEST.MF'
$script:ComfortEarlyLocation = 'file:/C:/VC/EDT.Comfort/plugin.early/'
# Прежнее имя бандла раннего старта: его записи из профиля убираются, каталога больше нет.
$script:ComfortEarlyOldName = 'tormozit.comfort.bslparser'

function Get-ComfortReleaseFromVersionFile {
    param([string]$VersionFile = $script:ComfortVersionFile)
    if (-not (Test-Path -LiteralPath $VersionFile)) {
        throw "version.txt not found: $VersionFile"
    }
    $release = $null
    Get-Content -LiteralPath $VersionFile -Encoding UTF8 | ForEach-Object {
        if ($_ -match '^\s*comfort\.release\s*=\s*(\d+\.\d+\.\d+)\s*(?:#.*)?$') {
            $release = $Matches[1]
        }
    }
    if (-not $release) {
        throw "comfort.release not found in $VersionFile (expected exactly three numbers, e.g. 1.0.2)"
    }
    return $release
}

function Get-ComfortExpectedQualifier {
    param([string]$VersionFile = $script:ComfortVersionFile)
    return "$(Get-ComfortReleaseFromVersionFile -VersionFile $VersionFile).qualifier"
}

function Get-ComfortManifestVersion {
    param([string]$ManifestPath = $script:ComfortManifestPath)
    if (-not (Test-Path -LiteralPath $ManifestPath)) {
        throw "MANIFEST.MF not found: $ManifestPath"
    }
    foreach ($line in [System.IO.File]::ReadAllLines($ManifestPath)) {
        if ($line -match '^Bundle-Version:\s*(.+)$') {
            return $Matches[1].Trim()
        }
    }
    throw "Bundle-Version not found in $ManifestPath"
}

function Get-ComfortBundlesInfoVersion {
    param([string]$BundlesInfoPath)
    if (-not (Test-Path -LiteralPath $BundlesInfoPath)) {
        return $null
    }
    foreach ($line in [System.IO.File]::ReadAllLines($BundlesInfoPath)) {
        if ($line -match '^tormozit\.comfort,([^,]+),') {
            return $Matches[1]
        }
    }
    return $null
}

function Get-ComfortDevPropertiesVersion {
    param([string]$DevPropertiesPath)
    if (-not (Test-Path -LiteralPath $DevPropertiesPath)) {
        return $null
    }
    $found = $null
    foreach ($line in [System.IO.File]::ReadAllLines($DevPropertiesPath)) {
        if ($line -match '^tormozit\.comfort;([^=]+)=bin,lib/jacob\.jar$') {
            $found = $Matches[1]
        }
    }
    return $found
}

function Get-ComfortDevPropertiesStaleLines {
    param([string]$DevPropertiesPath)
    if (-not (Test-Path -LiteralPath $DevPropertiesPath)) {
        return @()
    }
    $stale = [System.Collections.Generic.List[string]]::new()
    foreach ($line in [System.IO.File]::ReadAllLines($DevPropertiesPath)) {
        if ($line -match '^tormozit\.comfort;[^=]+=$') {
            [void]$stale.Add($line)
        }
    }
    return $stale.ToArray()
}

function Get-ComfortEarlyVersion {
    return Get-ComfortChecksVersion -ManifestPath $script:ComfortEarlyManifestPath
}

# Запись бандла сразу после tormozit.comfort (или замена существующей).
function Set-ComfortExtraBundleLine {
    param(
        [string[]]$BundleLines,
        [string]$SymbolicName,
        [string]$Line
    )
    $pattern = '^' + [regex]::Escape($SymbolicName) + ','
    for ($i = 0; $i -lt $BundleLines.Count; $i++) {
        if ($BundleLines[$i] -match $pattern) {
            $BundleLines[$i] = $Line
            return , $BundleLines
        }
    }
    $result = New-Object System.Collections.Generic.List[string]
    foreach ($existing in $BundleLines) {
        $result.Add($existing)
        if ($existing -match '^tormozit\.comfort,') {
            $result.Add($Line)
        }
    }
    return , $result.ToArray()
}

function Get-ComfortEarlyBundlesInfoLine {
    param([string]$BundlesInfoPath)
    if (-not (Test-Path -LiteralPath $BundlesInfoPath)) {
        return $null
    }
    foreach ($line in [System.IO.File]::ReadAllLines($BundlesInfoPath)) {
        if ($line -match '^tormozit\.comfort\.early,') {
            return $line
        }
    }
    return $null
}

function Get-ComfortChecksVersion {
    param([string]$ManifestPath = $script:ComfortChecksManifestPath)
    if (-not (Test-Path -LiteralPath $ManifestPath)) {
        throw "MANIFEST.MF not found: $ManifestPath"
    }
    foreach ($line in [System.IO.File]::ReadAllLines($ManifestPath)) {
        if ($line -match '^Bundle-Version:\s*(.+)$') {
            return $Matches[1].Trim()
        }
    }
    throw "Bundle-Version not found in $ManifestPath"
}

function Update-PdeOsgiComfortVersion {
    param(
        [string]$BundlesInfoPath,
        [string]$DevPropertiesPath,
        [string]$Qualifier
    )
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    if (-not (Test-Path -LiteralPath $BundlesInfoPath)) {
        throw "bundles.info not found: $BundlesInfoPath"
    }
    $bundleLines = [System.IO.File]::ReadAllLines($BundlesInfoPath)
    $bundleUpdated = $false
    for ($i = 0; $i -lt $bundleLines.Count; $i++) {
        if ($bundleLines[$i] -match '^tormozit\.comfort,') {
            $bundleLines[$i] = "tormozit.comfort,$Qualifier,$($script:ComfortPluginLocation),4,false"
            $bundleUpdated = $true
            break
        }
    }
    if (-not $bundleUpdated) {
        throw "tormozit.comfort entry not found in $BundlesInfoPath"
    }
    # Бандл проверок в этом файле обязателен: без записи Equinox его не ставит, и проверки
    # «Комфорта» пропадают из дерева доступных проверок EDT.
    $checksVersion = Get-ComfortChecksVersion
    $checksLine = "tormozit.comfort.checks,$checksVersion,$($script:ComfortChecksLocation),4,false"
    $bundleLines = Set-ComfortExtraBundleLine -BundleLines $bundleLines -SymbolicName 'tormozit.comfort.checks' -Line $checksLine
    # Бандл раннего старта: started=true — стартует вместе с фреймворком, до загрузки классов EDT и SWT.
    $oldEarlyPattern = '^' + [regex]::Escape($script:ComfortEarlyOldName) + ','
    $bundleLines = @($bundleLines | Where-Object { $_ -notmatch $oldEarlyPattern })
    $earlyVersion = Get-ComfortEarlyVersion
    $earlyLine = "tormozit.comfort.early,$earlyVersion,$($script:ComfortEarlyLocation),4,true"
    $bundleLines = Set-ComfortExtraBundleLine -BundleLines $bundleLines -SymbolicName 'tormozit.comfort.early' -Line $earlyLine
    [System.IO.File]::WriteAllLines($BundlesInfoPath, $bundleLines, $utf8NoBom)
    $devLines = @(
        '#',
        "#$(Get-Date -Format 'ddd MMM dd HH:mm:ss ''MSK'' yyyy')",
        "tormozit.comfort;$Qualifier=bin,lib/jacob.jar",
        "tormozit.comfort.checks;$checksVersion=bin",
        "tormozit.comfort.early;$earlyVersion=bin",
        '@ignoredot@=true',
        'tormozit.comfort=bin,lib/jacob.jar',
        'tormozit.comfort.checks=bin',
        'tormozit.comfort.early=bin'
    )
    [System.IO.File]::WriteAllLines($DevPropertiesPath, $devLines, $utf8NoBom)
}

function Test-ComfortOsgiVersionSync {
    param(
        [string]$ExpectedQualifier,
        [string]$ManifestPath = $script:ComfortManifestPath,
        [string]$BundlesInfoPath,
        [string]$DevPropertiesPath
    )
    $manifest = Get-ComfortManifestVersion -ManifestPath $ManifestPath
    $bundles = Get-ComfortBundlesInfoVersion -BundlesInfoPath $BundlesInfoPath
    $dev = Get-ComfortDevPropertiesVersion -DevPropertiesPath $DevPropertiesPath
    $stale = Get-ComfortDevPropertiesStaleLines -DevPropertiesPath $DevPropertiesPath
    $earlyLine = Get-ComfortEarlyBundlesInfoLine -BundlesInfoPath $BundlesInfoPath
    $earlyOk = [bool]$earlyLine -and $earlyLine.EndsWith(',true')
    # Версия бандла проверок в bundles.info обязана совпадать с его MANIFEST: при расхождении
    # simpleconfigurator молча не ставит бандл, и все проверки «Комфорта» пропадают.
    $checksExpected = Get-ComfortChecksVersion
    $checksBundles = $null
    if (Test-Path -LiteralPath $BundlesInfoPath) {
        foreach ($line in [System.IO.File]::ReadAllLines($BundlesInfoPath)) {
            if ($line -match '^tormozit\.comfort\.checks,([^,]+),') {
                $checksBundles = $Matches[1]
            }
        }
    }
    $checksOk = $checksBundles -eq $checksExpected
    $ok = ($manifest -eq $ExpectedQualifier) -and ($bundles -eq $ExpectedQualifier) -and ($dev -eq $ExpectedQualifier) -and ($stale.Count -eq 0) -and $earlyOk -and $checksOk
    return [PSCustomObject]@{
        Ok = $ok
        Expected = $ExpectedQualifier
        Manifest = $manifest
        BundlesInfo = $bundles
        DevProperties = $dev
        StaleDevLines = $stale
        EarlyLine = $earlyLine
        ChecksExpected = $checksExpected
        ChecksBundlesInfo = $checksBundles
    }
}

function Assert-ComfortOsgiVersionSync {
    param(
        [string]$Context,
        [string]$ExpectedQualifier,
        [string]$ManifestPath = $script:ComfortManifestPath,
        [string]$BundlesInfoPath,
        [string]$DevPropertiesPath
    )
    $state = Test-ComfortOsgiVersionSync -ExpectedQualifier $ExpectedQualifier `
        -ManifestPath $ManifestPath -BundlesInfoPath $BundlesInfoPath -DevPropertiesPath $DevPropertiesPath
    if ($state.Ok) {
        Write-Host "[$Context] tormozit.comfort OK: $($state.Expected)"
        return $state
    }
    $msg = @(
        "[$Context] Comfort OSGi version mismatch (tormozit.comfort).",
        "  Expected: $($state.Expected)",
        "  MANIFEST.MF: $($state.Manifest)",
        "  bundles.info: $($state.BundlesInfo)",
        "  dev.properties: $($state.DevProperties)",
        "  bundles.info tormozit.comfort.early (expected ...,4,true): $($state.EarlyLine)",
        "  tormozit.comfort.checks: MANIFEST $($state.ChecksExpected), bundles.info $($state.ChecksBundlesInfo)"
    )
    if ($state.StaleDevLines.Count -gt 0) {
        $msg += "  Stale dev.properties lines: $($state.StaleDevLines -join '; ')"
    }
    $msg += @(
        '',
        'Symptom: image could not be loaded / cannot resolve bundle tormozit.comfort.',
        'Fix: powershell -File site\scripts\restore-main.ps1 (close Eclipse first).',
        'Before Run: powershell -File site\scripts\assert-comfort-osgi.ps1'
    )
    throw ($msg -join [Environment]::NewLine)
}

function Repair-ComfortWorkspaceOsgiVersion {
    param([string]$Qualifier)
    $bundlesDst = Join-Path $script:ComfortWsOsgi $script:ComfortBundlesInfoRel
    $devDst = Join-Path $script:ComfortWsOsgi 'dev.properties'
    cmd /c "attrib -R `"$bundlesDst`"" | Out-Null
    cmd /c "attrib -R `"$devDst`"" | Out-Null
    Update-PdeOsgiComfortVersion -BundlesInfoPath $bundlesDst -DevPropertiesPath $devDst -Qualifier $Qualifier
    attrib +R $bundlesDst
    cmd /c "attrib -R `"$devDst`"" | Out-Null
    Write-Host "Repaired workspace OSGi: $Qualifier"
}
